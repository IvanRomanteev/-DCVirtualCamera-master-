#pragma once
#include "stdafx.h"
#include "PushGuids.h"
#include "VirtualCamera.h"

#include <olectl.h>

//////////////////////////////////////////////////////////////////////////
//  This file contains routines to register / Unregister the 
//  Directshow filter 'Virtual Cam'
//  We do not use the inbuilt BaseClasses routines as we need to register as
//  a capture source
//////////////////////////////////////////////////////////////////////////


#include <streams.h>
#include <initguid.h>
#include <dllsetup.h>
#include <stdio.h>



#pragma comment(lib, "kernel32")
#pragma comment(lib, "user32")
#pragma comment(lib, "gdi32")
#pragma comment(lib, "advapi32")
#pragma comment(lib, "winmm")
#pragma comment(lib, "ole32")
#pragma comment(lib, "oleaut32")

#ifdef _DEBUG
#pragma comment(lib, "strmbasd")
#else
#pragma comment(lib, "strmbase")
#endif

#include <olectl.h>
#include <initguid.h>
#include <dllsetup.h>

#define CreateComObject(clsid, iid, var) CoCreateInstance( clsid, NULL, CLSCTX_INPROC_SERVER, iid, (void **)&var);

STDAPI AMovieSetupRegisterServer(CLSID   clsServer, LPCWSTR szDescription, LPCWSTR szFileName, LPCWSTR szThreadingModel = L"Both", LPCWSTR szServerType = L"InprocServer32");
STDAPI AMovieSetupUnregisterServer(CLSID clsServer);


const AMOVIESETUP_MEDIATYPE AMSMediaTypesVCam =
{ &MEDIATYPE_Video      // clsMajorType
, &MEDIASUBTYPE_NULL }; // clsMinorType

const AMOVIESETUP_PIN AMSPinVCam =
{
	L"Output",             // Pin string name
	FALSE,                 // Is it rendered
	TRUE,                  // Is it an output
	FALSE,                 // Can we have none
	FALSE,                 // Can we have many
	&CLSID_NULL,           // Connects to filter
	NULL,                  // Connects to pin
	1,                     // Number of types
	&AMSMediaTypesVCam      // Pin Media types
};

const AMOVIESETUP_FILTER AMSFilterVCam =
{
	&CLSID_VIRTUALCAMERAFILTER,  // Filter CLSID
	g_wszVirtualCamera,     // String name
	MERIT_DO_NOT_USE,      // Filter merit
	1,                     // Number pins
	&AMSPinVCam             // Pin details
};

CFactoryTemplate g_Templates[] =
{
	{
		g_wszVirtualCamera,
		&CLSID_VIRTUALCAMERAFILTER,
		CVirtualCamera::CreateInstance,
		NULL,
		&AMSFilterVCam
	},

};

int g_cTemplates = sizeof(g_Templates) / sizeof(g_Templates[0]);


STDAPI RegisterFilters(BOOL bRegister)
{
	HRESULT hr = NOERROR;
	WCHAR achFileName[MAX_PATH];
	char achTemp[MAX_PATH];
	ASSERT(g_hInst != 0);

	if (0 == GetModuleFileNameA(g_hInst, achTemp, sizeof(achTemp)))
		return AmHresultFromWin32(GetLastError());
	
	MultiByteToWideChar(CP_ACP, 0L, achTemp, lstrlenA(achTemp) + 1,
		achFileName, NUMELMS(achFileName));

	/*std::string fileName = achTemp;
	fileName = fileName.substr(fileName.find_last_of("\\") + 1);
	printf(fileName.c_str());*/

	hr = CoInitialize(0);
	if (bRegister)
	{
		hr = AMovieSetupRegisterServer(CLSID_VIRTUALCAMERAFILTER, g_wszVirtualCamera, achFileName, L"Both", L"InprocServer32");
	}

	if (SUCCEEDED(hr))
	{
		IFilterMapper2 *fm = 0;
		hr = CreateComObject(CLSID_FilterMapper2, IID_IFilterMapper2, fm);
		if (SUCCEEDED(hr))
		{
			if (bRegister)
			{
				IMoniker *pMoniker = 0;
				REGFILTER2 rf2;
				rf2.dwVersion = 1;
				rf2.dwMerit = MERIT_DO_NOT_USE;
				rf2.cPins = 1;
				rf2.rgPins = &AMSPinVCam;
				hr = fm->RegisterFilter(CLSID_VIRTUALCAMERAFILTER, g_wszVirtualCamera, &pMoniker, &CLSID_VideoInputDeviceCategory, NULL, &rf2);
			}
			else
			{
				hr = fm->UnregisterFilter(&CLSID_VideoInputDeviceCategory, 0, CLSID_VIRTUALCAMERAFILTER);
			}
		}

		// release interface
		if (fm)
			fm->Release();
	}

	if (SUCCEEDED(hr) && !bRegister)
		hr = AMovieSetupUnregisterServer(CLSID_VIRTUALCAMERAFILTER);

	CoFreeUnusedLibraries();
	CoUninitialize();
	return hr;
}

// DLL.cpp


#include <stdio.h>

STDAPI RegisterFilters(BOOL bRegister);

STDAPI DllRegisterServer()
{
	return RegisterFilters(TRUE);
}

STDAPI DllUnregisterServer()
{
	return RegisterFilters(FALSE);
}

STDAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);

extern "C" BOOL APIENTRY DllMain(HANDLE hModule, DWORD  dwReason, LPVOID lpReserved)
{
	__try
	{
		return DllEntryPoint((HINSTANCE)(hModule), dwReason, lpReserved);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		ExitProcess(0);
	}

}

