# DCVirtualCamera
Virtual Camera (Virtual WebCam) is a DirectShow virtual camera filter that written by C++. It can connect to DCMediaDecoder and get video input streams from files, VOD and Live streams and capturing screens.



Compile and Build steps on MSVC 12.0 (Visual Studio 2013):
- Install Microsoft Windows SDK Version 7.1
- Get Libav* FFMPEG libraries
- Modify project headers & libraries refrence according to your step 1 & 2 installation.
- Build project.